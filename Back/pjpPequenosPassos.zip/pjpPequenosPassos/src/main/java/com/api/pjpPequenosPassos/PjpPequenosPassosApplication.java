package com.api.pjpPequenosPassos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PjpPequenosPassosApplication {

	public static void main(String[] args) {
		SpringApplication.run(PjpPequenosPassosApplication.class, args);
	}

}
