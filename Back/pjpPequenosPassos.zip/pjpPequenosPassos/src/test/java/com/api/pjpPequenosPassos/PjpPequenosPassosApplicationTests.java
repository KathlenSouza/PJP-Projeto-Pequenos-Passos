package com.api.pjpPequenosPassos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PjpPequenosPassosApplicationTests {

	@Test
	void contextLoads() {
	}

}
