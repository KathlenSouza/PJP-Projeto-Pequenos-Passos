package com.api.PequenosPassos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PequenosPassosApplicationTests {

	@Test
	void contextLoads() {
	}

}
