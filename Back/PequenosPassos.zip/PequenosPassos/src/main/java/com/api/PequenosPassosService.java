package com.api;

public interface PequenosPassosService {

}
