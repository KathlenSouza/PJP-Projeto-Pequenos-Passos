package com.api.PequenosPassos.dtos;

public record PequenosPassosRecordDto() {

}
