package com.api.PequenosPassos.service;

public interface PequenosPassosService {

}
