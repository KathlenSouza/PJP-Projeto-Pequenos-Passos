package com.api.PequenosPassos.repository;

public interface PequenosPassosRepository {

}
