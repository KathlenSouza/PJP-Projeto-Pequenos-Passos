/* Pequenos Passos - funcionalidade (comentado em português)
   Arquivo: funcionalidade.js
   Objetivo: deixar o front-end funcional, organizado e responsivo.
   Funcionalidades:
   - Navegação entre abas (páginas internas)
   - Armazenamento local com localStorage
   - Radar desenhado em canvas (offline)
   - Calendário simples offline (clique para adicionar eventos)
   - Atividades, Diário e Rede de Apoio com salvamento local
   - Geração de relatório em nova janela (para imprimir / salvar como PDF)
*/

/* ------------------------------ Helpers de armazenamento ------------------------------ */
/* Pequena camada para lidar com localStorage e JSON de forma segura */
const storage = {
  get(key, fallback) {
    try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch(e){ return fallback; }
  },
  set(key, value) { localStorage.setItem(key, JSON.stringify(value)); },
  clearAll() {
    ['pp_profile','pp_activities','pp_diary','pp_providers','pp_calendar','pp_radar'].forEach(k => localStorage.removeItem(k));
  }
};

/* ------------------------------ Navegação entre abas ------------------------------ */
/* Aqui fazemos a alternância visual entre as seções (sem recarregar a página).
   Cada botão no cabeçalho possui data-target="idDaSecao".
*/
const navButtons = document.querySelectorAll('.nav-link');
const pages = document.querySelectorAll('.page');

function showPage(id) {
  // Remove a classe active de todas as páginas e adiciona na selecionada
  pages.forEach(p => p.classList.remove('active'));
  const target = document.getElementById(id);
  if (target) target.classList.add('active');
  // Atualiza estilos dos botões
  navButtons.forEach(b => b.classList.toggle('active', b.dataset.target === id));
  // Ações específicas por aba (por exemplo, redesenhar radar quando for a aba radar)
  if (id === 'radar') drawRadarBig();
}

// Vincula evento aos botões de navegação
navButtons.forEach(b => {
  b.addEventListener('click', (e) => {
    const t = b.dataset.target;
    showPage(t);
  });
});

/* ------------------------------ Perfil (nome e idade) ------------------------------ */
/* Carrega e salva os dados básicos do perfil da criança */
const inputName = document.getElementById('inputName');
const inputAge = document.getElementById('inputAge');
const confName = document.getElementById('confName');
const confAge = document.getElementById('confAge');

function loadProfile() {
  // Carrega perfil salvo ou usa valores padrão
  const p = storage.get('pp_profile', { name: 'Sophia', age: 5 });
  if (inputName) inputName.value = p.name;
  if (inputAge) inputAge.value = p.age;
  if (confName) confName.value = p.name;
  if (confAge) confAge.value = p.age;
}

function saveProfile() {
  // Validação simples na idade (apenas 4..6 permitidos pelo sistema)
  const name = (inputName && inputName.value) ? inputName.value.trim() : 'Sem Nome';
  const age = Math.min(6, Math.max(4, Number((inputAge && inputAge.value) ? inputAge.value : 5)));
  const p = { name, age };
  storage.set('pp_profile', p);
  alert('Perfil salvo localmente');
}

/* ------------------------------ Radar (canvas) ------------------------------ */
/* Desenhamos um radar simples em canvas para evitar dependências externas.
   O radar usa 4 dimensões: Motor, Social, Cognitivo, Linguagem.
   Os valores são carregados de pp_radar no localStorage (se existentes).
*/

function defaultRadar() {
  return storage.get('pp_radar', { motor:75, social:80, cognitive:60, language:70 });
}

/* Função de desenho geral do radar */
function drawRadar(canvas, valuesObj) {
  if(!canvas) return;
  const ctx = canvas.getContext('2d');
  const w = canvas.width, h = canvas.height;
  ctx.clearRect(0,0,w,h);

  // centro e raio
  const cx = w/2, cy = h/2;
  const radius = Math.min(w,h)/2 - 40;
  const labels = ['Motor','Social','Cognitivo','Linguagem'];
  const values = [valuesObj.motor, valuesObj.social, valuesObj.cognitive, valuesObj.language];

  // 1) Desenha níveis concêntricos (grade)
  ctx.strokeStyle = 'rgba(15,23,42,0.06)';
  ctx.lineWidth = 1;
  for(let r=1;r<=5;r++){
    ctx.beginPath();
    ctx.arc(cx,cy,(radius/5)*r,0,Math.PI*2);
    ctx.stroke();
  }

  // 2) Área preenchida com os valores
  ctx.beginPath();
  values.forEach((v,i)=>{
    const ang = -Math.PI/2 + (i*(Math.PI*2)/values.length);
    const r = (v/100)*radius;
    const x = cx + Math.cos(ang)*r;
    const y = cy + Math.sin(ang)*r;
    if(i===0) ctx.moveTo(x,y); else ctx.lineTo(x,y);
  });
  ctx.closePath();
  ctx.fillStyle = 'rgba(125,184,255,0.28)'; // tonalidade azul suave
  ctx.fill();
  ctx.strokeStyle = 'rgba(34,102,255,0.9)';
  ctx.lineWidth = 2;
  ctx.stroke();

  // 3) Pontos de cada dimensão
  values.forEach((v,i)=>{
    const ang = -Math.PI/2 + (i*(Math.PI*2)/values.length);
    const r = (v/100)*radius;
    const x = cx + Math.cos(ang)*r;
    const y = cy + Math.sin(ang)*r;
    ctx.beginPath();
    ctx.arc(x,y,5,0,Math.PI*2);
    ctx.fillStyle = 'rgba(34,102,255,0.95)';
    ctx.fill();
  });

  // 4) Legendas ao redor
  ctx.fillStyle = '#0f172a';
  ctx.font = '14px Inter, Arial';
  labels.forEach((lab,i)=>{
    const ang = -Math.PI/2 + (i*(Math.PI*2)/labels.length);
    const x = cx + Math.cos(ang)*(radius+24);
    const y = cy + Math.sin(ang)*(radius+24)+6;
    ctx.fillText(lab, x - (lab.length*4), y);
  });
}

/* Atualiza radar nos canvases small e big, e também a legenda textual */
function updateRadarUI() {
  const r = defaultRadar();
  drawRadar(document.getElementById('radarCanvas'), r);
  drawRadar(document.getElementById('radarCanvasBig'), r);
  const legend = document.getElementById('radarLegend');
  if (legend) legend.innerHTML = `<div class="item">Motor: ${r.motor}%</div><div class="item">Social: ${r.social}%</div><div class="item">Cognitivo: ${r.cognitive}%</div><div class="item">Linguagem: ${r.language}%</div>`;
  const stats = document.getElementById('radarStats');
  if(stats) stats.innerHTML = legend ? legend.innerHTML : '';
}

/* Função chamada ao abrir a aba radar (redesenha) */
function drawRadarBig(){ updateRadarUI(); }

/* ------------------------------ Calendário (offline simples) ------------------------------ */
/* Implementação simples de calendário mensal (sem FullCalendar) para uso offline.
   Clique em um dia para adicionar um evento/vacina (salvo em localStorage).
*/
function renderCalendar() {
  const container = document.getElementById('calendar');
  if(!container) return;
  container.innerHTML = '';
  const now = new Date();
  const year = now.getFullYear(), month = now.getMonth();
  const first = new Date(year, month, 1);
  const startDay = first.getDay(); // dia da semana do primeiro dia
  const days = new Date(year, month+1, 0).getDate();

  // header
  const header = document.createElement('div');
  header.className = 'calendar-header';
  header.innerHTML = `<strong>${first.toLocaleString('pt-BR',{month:'long',year:'numeric'})}</strong>`;
  container.appendChild(header);

  // grid
  const grid = document.createElement('div');
  grid.className = 'calendar-grid';
  grid.style.display='grid';
  grid.style.gridTemplateColumns='repeat(7,1fr)';
  grid.style.gap='6px';

  // dias vazios antes do primeiro dia
  for(let i=0;i<startDay;i++){
    const d = document.createElement('div'); d.className='day blank'; grid.appendChild(d);
  }

  // eventos existentes no mês (salvos por dia)
  const events = storage.get('pp_calendar', [{title:'Reforço DTP', day: new Date().getDate()}]);

  for(let d=1; d<=days; d++){
    const dayBox = document.createElement('div'); dayBox.className='day';
    dayBox.innerHTML = `<div class="date">${d}</div>`;
    // mostrar eventos desse dia
    const evs = events.filter(e=>e.day===d);
    evs.forEach(ev=>{
      const div = document.createElement('div'); div.className='ev'; div.textContent = ev.title;
      div.style.background='linear-gradient(90deg,var(--yellow),#ffd27a)';
      div.style.padding='6px'; div.style.borderRadius='8px'; div.style.marginTop='6px'; div.style.fontSize='12px';
      dayBox.appendChild(div);
    });
    // clique para adicionar evento simples
    dayBox.addEventListener('click', ()=>{
      const title = prompt('Nome do evento ou vacina para o dia ' + d + ':');
      if(title){
        events.push({title, day:d});
        storage.set('pp_calendar', events);
        renderCalendar();
      }
    });
    grid.appendChild(dayBox);
  }
  container.appendChild(grid);
}

/* ------------------------------ Atividades ------------------------------ */
/* CRUD simples para criar, marcar como feito e remover atividades.
   Salva os dados em pp_activities no localStorage.
*/
const activityForm = document.getElementById('activityForm');
const activitiesList = document.getElementById('activitiesList');

function loadActivities(){ return storage.get('pp_activities', []); }
function saveActivities(a){ storage.set('pp_activities', a); }

if(activityForm){
  activityForm.addEventListener('submit', (e)=>{
    e.preventDefault();
    const descElem = document.getElementById('activityDesc');
    const catElem = document.getElementById('activityCategory');
    const desc = descElem ? descElem.value.trim() : '';
    const cat = catElem ? catElem.value : 'Motor';
    if(!desc) return alert('Descrição obrigatória');
    const arr = loadActivities();
    arr.unshift({id:Date.now(),desc,cat,done:false});
    saveActivities(arr); renderActivities();
  });
}

function renderActivities(){
  const arr = loadActivities();
  if(!activitiesList) return;
  activitiesList.innerHTML = '';
  if(!arr.length) { activitiesList.innerHTML = '<div class="muted">Nenhuma atividade</div>'; return; }
  arr.forEach(a=>{
    const li = document.createElement('li');
    li.innerHTML = `<div>${escapeHtml(a.desc)} <small class="muted">(${a.cat})</small></div>
                    <div><label><input type="checkbox" data-id="${a.id}" ${a.done? 'checked':''}> Concluído</label>
                    <button data-id="${a.id}" class="btn">Excluir</button></div>`;
    activitiesList.appendChild(li);
    // eventos dos botões/checkboxes
    const checkbox = li.querySelector('input[type="checkbox"]');
    checkbox.addEventListener('change', (e)=>{
      const id = Number(e.target.dataset.id);
      const idx = arr.findIndex(x=>x.id===id); if(idx>=0){ arr[idx].done = e.target.checked; saveActivities(arr); updateFromActivities(); }
    });
    li.querySelector('button').addEventListener('click', ()=>{
      const id = Number(li.querySelector('button').dataset.id);
      const filtered = arr.filter(x=>x.id!==id); saveActivities(filtered); renderActivities();
    });
  });
}

/* Botão limpar atividades */
const btnClearActivities = document.getElementById('btnClearActivities');
if(btnClearActivities){
  btnClearActivities.addEventListener('click', ()=>{
    if(confirm('Remover todas as atividades?')){ saveActivities([]); renderActivities(); }
  });
}

/* Atualiza radar com base nas atividades (simples heurística) */
function updateFromActivities(){
  const arr = loadActivities();
  if(!arr.length) return;
  const groups = {Motor:[],Social:[],Cognitivo:[],Linguagem:[]};
  arr.forEach(a=> groups[a.cat].push(a));
  const calc = g=> g.length ? Math.round((g.filter(x=>x.done).length/g.length)*100) : 70;
  const radar = { motor:calc(groups.Motor), social:calc(groups.Social), cognitive:calc(groups.Cognitivo), language:calc(groups.Linguagem) };
  storage.set('pp_radar', radar);
  updateRadarUI();
}

/* ------------------------------ Diário ------------------------------ */
const diaryForm = document.getElementById('diaryForm');
const diaryList = document.getElementById('diaryList');
function loadDiary(){ return storage.get('pp_diary', []); }
function saveDiary(a){ storage.set('pp_diary', a); }

if(diaryForm){
  diaryForm.addEventListener('submit', (e)=>{
    e.preventDefault();
    const title = document.getElementById('diaryTitle').value || 'Entrada';
    const content = document.getElementById('diaryContent').value || '';
    const arr = loadDiary();
    arr.unshift({id:Date.now(),title,content,date:new Date().toISOString()});
    saveDiary(arr); renderDiary();
  });
}

function renderDiary(){
  const arr = loadDiary(); if(!diaryList) return;
  diaryList.innerHTML = '';
  if(!arr.length) { diaryList.innerHTML = '<div class="muted">Nenhuma entrada</div>'; return; }
  arr.forEach(d=>{
    const div = document.createElement('div'); div.className='day-entry';
    div.innerHTML = `<strong>${escapeHtml(d.title)}</strong> <small class="muted">${new Date(d.date).toLocaleString()}</small><p>${escapeHtml(d.content)}</p>
      <div><button class="btn" data-id="${d.id}">Excluir</button></div>`;
    diaryList.appendChild(div);
    div.querySelector('button').addEventListener('click', ()=> {
      if(confirm('Excluir?')){ const id=Number(div.querySelector('button').dataset.id); const filtered=arr.filter(x=>x.id!==id); saveDiary(filtered); renderDiary(); }
    });
  });
}

/* ------------------------------ Rede de Apoio (Providers) ------------------------------ */
const providerForm = document.getElementById('providerForm');
const providersList = document.getElementById('providersList');
function loadProviders(){ return storage.get('pp_providers', [
  {id:1,name:'Dra. Ana Silva',specialty:'Pediatra',contact:'(47)99999-0000'},
  {id:2,name:'Prof. Carla',specialty:'Fonoaudiologia',contact:'carla@example.com'}
]);}
function saveProviders(a){ storage.set('pp_providers', a); }

if(providerForm){
  providerForm.addEventListener('submit', (e)=>{
    e.preventDefault();
    const name = document.getElementById('providerName').value.trim();
    const specialty = document.getElementById('providerSpecialty').value.trim();
    const contact = document.getElementById('providerContact').value.trim();
    if(!name) return alert('Nome obrigatório');
    const arr = loadProviders(); arr.unshift({id:Date.now(),name,specialty,contact}); saveProviders(arr); renderProviders();
  });
}

function renderProviders(){
  const arr = loadProviders(); if(!providersList) return;
  providersList.innerHTML = '';
  arr.forEach(p=>{
    const li = document.createElement('li');
    li.innerHTML = `<div><strong>${escapeHtml(p.name)}</strong><div class="muted">${escapeHtml(p.specialty)} • ${escapeHtml(p.contact)}</div></div>
      <div><button class="btn" data-id="${p.id}">Contato</button> <button class="btn" data-id="${p.id}">Excluir</button></div>`;
    providersList.appendChild(li);
    const buttons = li.querySelectorAll('button');
    buttons[0].addEventListener('click', ()=> alert('Contato: '+p.contact));
    buttons[1].addEventListener('click', ()=> { if(confirm('Remover profissional?')){ const filtered=arr.filter(x=>x.id!==p.id); saveProviders(filtered); renderProviders(); }});
  });
}

/* ------------------------------ Relatório (abrir nova janela para impressão/PDF) ------------------------------ */
document.getElementById('btnPreviewReport')?.addEventListener('click', ()=> openReport(true));
document.getElementById('btnExportReport')?.addEventListener('click', ()=> openReport(false));

function openReport(preview){
  const profile = storage.get('pp_profile', {name:'Sem nome', age:5});
  const notes = document.getElementById('reportNotes') ? document.getElementById('reportNotes').value : '';
  const canvas = document.getElementById('radarCanvas');
  const img = canvas ? canvas.toDataURL('image/png') : '';
  const w = window.open('','_blank');
  const html = `
    <html><head><title>Relatório - ${profile.name}</title><style>body{font-family:Arial;padding:20px} .header{display:flex;gap:12px;align-items:center} .logo{width:60px}</style></head>
    <body>
      <div class="header"><img src="SRC/STATIC/IMG/logo.svg" class="logo"><h1>Pequenos Passos - Relatório</h1></div>
      <p><strong>Nome:</strong> ${profile.name} — <strong>Idade:</strong> ${profile.age}</p>
      <h3>Radar</h3>${ img ? '<img src="'+img+'" style="max-width:520px;border:1px solid #ddd;padding:8px;background:white">' : '<p>(sem gráfico)</p>' }
      <h3>Observações</h3><p>${escapeHtml(notes)}</p>
      <hr><p>Gerado localmente — imprimir/Salvar como PDF no navegador.</p>
    </body></html>`;
  w.document.write(html);
  w.document.close();
  if(!preview){ w.focus(); setTimeout(()=> w.print(), 700); }
}

/* ------------------------------ Utilitários ------------------------------ */
function escapeHtml(s){ if(!s) return ''; return s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;'); }

/* ------------------------------ Inicialização da aplicação ------------------------------ */
function initAll(){
  loadProfile(); renderCalendar(); updateRadarUI(); renderActivities(); renderDiary(); renderProviders();
  // sincroniza campos de configuração com perfil salvo
  const p = storage.get('pp_profile', {name:'Sophia',age:5});
  if(document.getElementById('confName')) document.getElementById('confName').value = p.name;
  if(document.getElementById('confAge')) document.getElementById('confAge').value = p.age;
}

/* Eventos de botão (perfil e settings) */
document.getElementById('btnSaveProfile')?.addEventListener('click', saveProfile);
document.getElementById('btnSaveSettings')?.addEventListener('click', ()=>{
  const p = { name: document.getElementById('confName').value || 'Sem Nome', age: Math.min(6,Math.max(4,Number(document.getElementById('confAge').value || 5))) };
  storage.set('pp_profile', p);
  alert('Configurações salvas');
});

/* Reset de dados locais */
document.getElementById('btnResetAll')?.addEventListener('click', ()=>{
  if(confirm('Resetar todos os dados locais?')){ storage.clearAll(); initAll(); alert('Dados apagados'); }
});

/* Inicia quando o DOM estiver carregado */
window.addEventListener('DOMContentLoaded', initAll);
